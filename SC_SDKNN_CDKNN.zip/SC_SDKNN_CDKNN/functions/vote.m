function x=vote(vec)
au=unique(vec);
x=vec(vec==au(1));
