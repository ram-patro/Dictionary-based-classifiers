function [D1,D2,D3]=create_dictionary(data,class)
D1=data;
D3=class;
[~,loc]=sort(data,2);[~,D2]=sort(loc,2);
    
