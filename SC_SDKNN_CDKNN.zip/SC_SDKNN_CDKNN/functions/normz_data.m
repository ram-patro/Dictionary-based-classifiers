function data_normalized=normz_data(data)
data_shifted=(data-min(data));
data_normalized=data_shifted./max(data_shifted);