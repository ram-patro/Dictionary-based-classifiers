function [test_D3_out]=classifier_SC(test_D1,test_D2,train_D1,train_D2,train_D3)
for i=1:size(test_D1,1)
    score=sum(abs(test_D2(i,:)-train_D2),2);
    Tie=score==min(score);
    DT=train_D3(Tie);
    V=vote(DT);
    if(numel(V)==1)
        test_D3_out(i,1)=V;
    else
        score1=sum(abs(test_D1(i,:)-train_D1(Tie,:)),2);
        Tie1=score1==min(score1);
        VV=vote(DT(Tie1));
        test_D3_out(i,1)=VV(ceil(rand*numel(VV)));
    end
    h=waitbar(i/size(test_D1,1));
end
close(h);