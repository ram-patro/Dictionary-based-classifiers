function [D1_S,D2_S,D3_S]=sparse_dictionary(D1,D2,D3,sp)
c=numel(unique(D3));
D1_S=[];D2_S=[];D3_S=[];
for x=1:c
    j=0;
    K1=D2(D3==x,:);K2=D1(D3==x,:);K3=D3(D3==x,:);
    sr=size(K1,1);
    dif=[];
    for i=1:size(K1,1)-1
        dif=[dif sum(abs(K1(i,:)-K1(i+1,:)),2)];
        h=waitbar(i/(size(K1,1)-1));
    end
    close(h);   
    d_max=max(dif);
    while(j<sr)
        j=j+1;
        d=sum(abs(K1(j,:)-K1(j+1:end,:)),2);
        d=[zeros(j,1);d];
        locs=d<d_max*sp;
        locs(1:j)=0;
        K1(locs,:)=[];
        K2(locs,:)=[];
        K3(locs,:)=[];
        sr=size(K1,1);
    end
    D2_S=[D2_S;K1];
    D1_S=[D1_S;K2];
    D3_S=[D3_S;K3];
    h=waitbar(c/x);
end
close(h);