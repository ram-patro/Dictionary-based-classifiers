If found useful, pleaase cite as

@article{doi:10.1080/01431161.2019.1577580,
author = {Ram Narayan Patro and Subhashree Subudhi and Pradyut Kumar Biswal and Fabio Dell�Acqua},
title = {Dictionary-based classifiers for exploiting feature sequence information and their application to hyperspectral remotely sensed data},
journal = {International Journal of Remote Sensing},
volume = {0},
number = {0},
pages = {1-29},
year  = {2019},
publisher = {Taylor & Francis},
doi = {10.1080/01431161.2019.1577580},
URL = { https://doi.org/10.1080/01431161.2019.1577580},
eprint = { https://doi.org/10.1080/01431161.2019.1577580}}
