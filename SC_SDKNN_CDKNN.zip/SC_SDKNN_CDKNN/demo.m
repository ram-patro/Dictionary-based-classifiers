clear
close all
clc

addpath(genpath(pwd));

%add your data set to perform the classification

%Hill Valley with out noise data collected from UCI machine repository
load data
load class


per=10;
c=cvpartition(class,'HoldOut',1-(per/100));
train_loc=c.training;
test_loc=~train_loc;

%Simple k-NN classifier (k-NN)
k=5;
Mdl=fitcknn(data(train_loc,:),class(train_loc,1),'NumNeighbors',k);
[class_out,~]=predict(Mdl,data(test_loc,:));
[oa(1), aa(1), K(1), ua(:,1)]=perf_measure(class(test_loc,1),class_out);


data=normz_data(data);
[D1,D2,D3]=create_dictionary(data,class);

train_D1=D1(train_loc,:);
train_D2=D2(train_loc,:);
train_D3=D3(train_loc,:);

test_D1=D1(test_loc,:);
test_D2=D2(test_loc,:);
test_D3=D3(test_loc,:);

%Sparse training dictionary creation
sp=0;
[train_D1,train_D2,train_D3]=sparse_dictionary(train_D1,train_D2,train_D3,sp);

%Sequence classifier (SC)
[test_D3_out]=classifier_SC(test_D1,test_D2,train_D1,train_D2,train_D3);
[oa(2), aa(2), K(2), ua(:,2)]=perf_measure(test_D3,test_D3_out);

%Sequence Distance based k-NN classifier (SDKNN)
k=5;
Mdl=fitcknn(train_D2,train_D3,'NumNeighbors',k);
[test_D3_out,~]=predict(Mdl,test_D2);
[oa(3), aa(3), K(3), ua(:,3)]=perf_measure(test_D3,test_D3_out);

%Combined Distance based k-NN classifier (CDKNN)
k=5;
p=0.5;
Mdl=fitcknn([p.*train_D1 (1-p).*(train_D2./max(train_D2(:)))],train_D3,'NumNeighbors',k);
[test_D3_out,~]=predict(Mdl,[p.*test_D1 (1-p).*(test_D2./max(train_D2(:)))]);
[oa(4), aa(4), K(4), ua(:,4)]=perf_measure(test_D3,test_D3_out);

disp('Overall Accuracy');
disp(['      KNN   ' '     SC   ' '   SDKNN   ' ' CDKNN   ']);
disp(oa);
disp('Average Accuracy');
disp(['      KNN   ' '     SC   ' '   SDKNN   ' ' CDKNN   ']);
disp(aa);
disp('Kappa');
disp(['      KNN   ' '     SC   ' '   SDKNN   ' ' CDKNN   ']);
disp(K);
disp('Individual Class');
disp(['      KNN   ' '     SC   ' '   SDKNN   ' ' CDKNN   ']);
disp(ua);